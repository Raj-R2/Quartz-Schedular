package com.example.quartzdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class QuartzDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
